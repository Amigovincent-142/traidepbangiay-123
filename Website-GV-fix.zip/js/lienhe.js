
function handleSubmit(event) {
  event.preventDefault();
  alert("Cảm ơn bạn đã gửi yêu cầu! Shop sẽ phản hồi sớm nhất có thể.");
}
